ex <- matrix(scan("ex.txt", quiet=TRUE), nc=4, byr=TRUE)
dimnames(ex) <- list(NULL, c("x1","x2","y1","y2"))

