# viridis 0.6.2

## New features

* N/A. 

## Minor improvements and fixes

* Fix minor check warnings requested by CRAN. 

---

# viridis 0.6.1

## New features

* N/A. 

## Minor improvements and fixes

* Include unemployment data in package to avoid CRAN check errors when original
 data is not accessible. 

---

# viridis 0.6.0

## New features

* Add 3 more color maps: mako, rocket, and turbo. 

## Minor improvements and fixes

* Minor bug fixes and improvements here and there. 

---
